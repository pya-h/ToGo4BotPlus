# Togo Package
This package is written for togo4bot telegram bot repo; (And a similar one is written for togo4 (console app))
Run this:
go install
